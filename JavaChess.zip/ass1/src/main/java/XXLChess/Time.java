package XXLChess;
public class Time {
    private long startTime;
    private long passedTime;
    private boolean running = false;
    private long time;
    private int increase;

    public Time(int minutes, int seconds, int increment){
        this.time = minutes*60*1000 + seconds*1000;
        this.increase = increment;
    }

    /**
     * Set timer start time
     */
    public void start(){
        if(!running){
            this.startTime = System.currentTimeMillis();
            this.running = true;
        }
    }

    /**
     * Set timer stop time
     */
    public void stop(){
        if(running){
            this.passedTime = System.currentTimeMillis() - this.startTime;
            this.time -= this.passedTime;
            this.time += this.increase * 1000;
            this.running = false;
        }

    }

    /**
     * Set timer finish time
     */
    public void finish(){
        if(running){
            this.passedTime = System.currentTimeMillis() - this.startTime;
            this.time -= this.passedTime;
        }
        if(time < 0){
            time = 0;
        }
        running = false;
    }

    public long getTime(){
        long time = this.time;
        if (running){
            this.passedTime = System.currentTimeMillis() - this.startTime;
            time = this.time - (this.passedTime);
        }
        return time/1000;
    }

    public boolean isRunning(){
        return this.running;
    }

}
