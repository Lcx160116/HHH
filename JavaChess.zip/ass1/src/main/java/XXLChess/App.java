package XXLChess;

//import org.reflections.Reflections;
//import org.reflections.scanners.Scanners;

import processing.core.PApplet;
import processing.core.PImage;
import processing.data.JSONObject;
import processing.event.MouseEvent;

import java.lang.Math;

import java.io.*;
import java.util.*;


public class App extends PApplet {

    public static final int SPRITESIZE = 480;
    public static final int CELLSIZE = 48;
    public static final int SIDEBAR = 120;
    public static final int BOARD_WIDTH = 14;
    public Grid[][] board = new Grid[14][14];
    private static int xClicked = 5;
    private static int yClicked = 5;
    private Grid selectedCell;
    public static PImage bAmazon;
    public static PImage bArchbishop;
    public static PImage bBishop;
    public static PImage bCamel;
    public static PImage bChancellor;
    public static PImage bKing;
    public static PImage bKnight;
    public static PImage bKnightKing;
    public static PImage bPawn;
    public static PImage bQueen;
    public static PImage bRook;
    public static PImage wAmazon;
    public static PImage wArchbishop;
    public static PImage wBishop;
    public static PImage wCamel;
    public static PImage wChancellor;
    public static PImage wKing;
    public static PImage wKnight;
    public static PImage wKnightKing;
    public static PImage wPawn;
    public static PImage wQueen;
    public static PImage wRook;
    public static int WIDTH = CELLSIZE * BOARD_WIDTH + SIDEBAR;
    public static int HEIGHT = BOARD_WIDTH * CELLSIZE;
    public static final int FPS = 120;
    private boolean click;
    public Player turn;
    public String configPath;
    public int[][] lastMove;
    private Time timerWhite, timerBlack;
    private AI ai;
    private boolean resigned;

    public App() {
        this.configPath = "config.json";
    }

    /**
     * Initialise the setting of the window size.
     */
    public void settings() {
        size(WIDTH, HEIGHT);
    }

    /**
     * Load various chess piece position information
     * @param fileName Configuration file name containing chess piece position information
     */
    public void loadBoard(String fileName) {
        try {
            File f = new File(fileName);
            BufferedReader br = new BufferedReader(new FileReader(f));
            int j = 0;
            while (j < BOARD_WIDTH) {

                String line = br.readLine();
                int i = 0;
                while (i < line.length()) {
                    char type = line.charAt(i);
                    if (type == 'P')
                        board[i][j].setPiece(new Pawn(Player.BLACK, bPawn, i, j));
                    if (type == 'R')
                        this.board[i][j].setPiece(new Rook(Player.BLACK, bRook, i, j));
                    if (type == 'N')
                        this.board[i][j].setPiece(new Knight(Player.BLACK, bKnight, i, j));
                    if (type == 'B')
                        this.board[i][j].setPiece(new Bishop(Player.BLACK, bBishop, i, j));
                    if (type == 'H')
                        this.board[i][j].setPiece(new Archbishop(Player.BLACK, bArchbishop, i, j));
                    if (type == 'C')
                        this.board[i][j].setPiece(new Camel(Player.BLACK, bCamel, i, j));
                    if (type == 'G')
                        this.board[i][j].setPiece(new Guard(Player.BLACK, bKnightKing, i, j));
                    if (type == 'A')
                        this.board[i][j].setPiece(new Amazon(Player.BLACK, bAmazon, i, j));
                    if (type == 'K')
                        this.board[i][j].setPiece(new King(Player.BLACK, bKing, i, j));
                    if (type == 'E')
                        this.board[i][j].setPiece(new Chancellor(Player.BLACK, bChancellor, i, j));
                    if (type == 'Q')
                        this.board[i][j].setPiece(new Queen(Player.BLACK, bQueen, i, j));
                    if (type == 'p')
                        board[i][j].setPiece(new Pawn(Player.WHITE, wPawn, i, j));
                    if (type == 'r')
                        this.board[i][j].setPiece(new Rook(Player.WHITE, wRook, i, j));
                    if (type == 'n')
                        this.board[i][j].setPiece(new Knight(Player.WHITE, wKnight, i, j));
                    if (type == 'b')
                        this.board[i][j].setPiece(new Bishop(Player.WHITE, wBishop, i, j));
                    if (type == 'h')
                        this.board[i][j].setPiece(new Archbishop(Player.WHITE, wArchbishop, i, j));
                    if (type == 'c')
                        this.board[i][j].setPiece(new Camel(Player.WHITE, wCamel, i, j));
                    if (type == 'g')
                        this.board[i][j].setPiece(new Guard(Player.WHITE, wKnightKing, i, j));
                    if (type == 'a')
                        this.board[i][j].setPiece(new Amazon(Player.WHITE, wAmazon, i, j));
                    if (type == 'k')
                        this.board[i][j].setPiece(new King(Player.WHITE, wKing, i, j));
                    if (type == 'e')
                        this.board[i][j].setPiece(new Chancellor(Player.WHITE, wChancellor, i, j));
                    if (type == 'q')
                        this.board[i][j].setPiece(new Queen(Player.WHITE, wQueen, i, j));
                    i++;
                }
                j++;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * Load all resources such as images. Initialise the elements such as the player, enemies and map elements.
     */
    public void setup() {
        frameRate(FPS);

        // Load images during setup
        bAmazon = loadImage("XXLChess/b-amazon.png");
        bArchbishop = loadImage("XXLChess/b-archbishop.png");
        bBishop = loadImage("XXLChess/b-bishop.png");
        bCamel = loadImage("XXLChess/b-camel.png");
        bChancellor = loadImage("XXLChess/b-chancellor.png");
        bKing = loadImage("XXLChess/b-king.png");
        bKnight = loadImage("XXLChess/b-knight.png");
        bKnightKing = loadImage("XXLChess/b-knight-king.png");
        bPawn = loadImage("XXLChess/b-pawn.png");
        bQueen = loadImage("XXLChess/b-queen.png");
        bRook = loadImage("XXLChess/b-rook.png");
        bRook = loadImage("XXLChess/b-rook.png");
        wAmazon = loadImage("XXLChess/w-amazon.png");
        wArchbishop = loadImage("XXLChess/w-archbishop.png");
        wBishop = loadImage("XXLChess/w-bishop.png");
        wCamel = loadImage("XXLChess/w-camel.png");
        wChancellor = loadImage("XXLChess/w-chancellor.png");
        wKing = loadImage("XXLChess/w-king.png");
        wKnight = loadImage("XXLChess/w-knight.png");
        wKnightKing = loadImage("XXLChess/w-knight-king.png");
        wPawn = loadImage("XXLChess/w-pawn.png");
        wQueen = loadImage("XXLChess/w-queen.png");
        wRook = loadImage("XXLChess/w-rook.png");

        int i = 0;
        while (i < BOARD_WIDTH) {
            int j = 0;
            while (j < BOARD_WIDTH) {
                if ((i + j) % 2 == 0) this.board[i][j] = new Grid(OtherColor.LIGHT_BROWN);
                else this.board[i][j] = new Grid(OtherColor.DARK_BROWN);
                j++;
            }
            i++;
        }

        JSONObject conf = loadJSONObject(new File(this.configPath));
        String fileName = conf.getString("layout");

        int secondsPlayer = conf.getJSONObject("time_controls").getJSONObject("player").getInt("seconds");
        int incrementPlayer = conf.getJSONObject("time_controls").getJSONObject("player").getInt("increment");

        int secondsCpu = conf.getJSONObject("time_controls").getJSONObject("cpu").getInt("seconds");
        int incrementCpu = conf.getJSONObject("time_controls").getJSONObject("cpu").getInt("increment");

        Player colourPlayer = (("white".equals(conf.getString("player_colour"))) ? Player.WHITE : Player.BLACK);
        Player colourCpu = (("white".equals(conf.getString("player_colour"))) ? Player.BLACK : Player.WHITE);

        if (colourPlayer == Player.WHITE) {
            timerWhite = new Time((int) secondsPlayer / 60, secondsPlayer % 60, incrementPlayer);
            timerBlack = new Time((int) secondsCpu / 60, secondsCpu % 60, incrementCpu);
        } else {
            timerWhite = new Time((int) secondsCpu / 60, secondsCpu % 60, incrementCpu);
            timerBlack = new Time((int) secondsPlayer / 60, secondsPlayer % 60, incrementPlayer);
        }

        turn = Player.WHITE;
        loadBoard(fileName);
        ai = new AI(this, colourCpu);
        resigned = false;
        lastMove = new int[][]{null, null};



    }

    /**
     * Receive key pressed signal from the keyboard.
     */
    @Override
    public void keyPressed() {
        if (key == 'r') {
            setup();
        }
        if (key == 'e') {
            resigned = true;
        }
    }

    /**
     * Receive click from the mouse.
     * @param e Mouse click event
     */
    @Override
    public void mousePressed(MouseEvent e) {
        xClicked = e.getX() / CELLSIZE;
        yClicked = e.getY() / CELLSIZE;
        click = true;
    }

    /**
     * Draw all elements in the game by current frame.
     */
    public void draw() {
        background(180, 180, 180);
        showBoard();
        textSize(30);
        fill(255, 255, 255);
        if (resigned) {
            textSize(12);
            text("You resigned", 680, 250);
            return;
        }
        updateTime(timerWhite, timerBlack, turn);
        displayTime(timerWhite, timerBlack, turn);
        if (timerBlack.getTime() <= 0) {
            fill(255, 255, 255);
            textSize(12);
            text("You win on time", 680, 250);
            text("Press 'r' to restart", 680, 300);
            text("the game", 680, 315);
            timerBlack.finish();
            timerWhite.finish();
        } else if (timerWhite.getTime() <= 0) {
            fill(255, 255, 255);
            textSize(12);
            text("You lose on time", 680, 250);
            text("Press 'r' to restart", 680, 300);
            text("the game", 680, 315);
            timerBlack.finish();
            timerWhite.finish();
        } else if (isCheckMate(turn)&&this.turn==Player.WHITE) {
            fill(255, 255, 255);
            textSize(12);
            text("You lose by", 680, 250);
            text("checkmate", 680, 265);
        } else if (isCheckMate(turn)&&this.turn==Player.BLACK) {
            fill(255, 255, 255);
            textSize(12);
            text("You win by", 680, 250);
            text("checkmate", 680, 265);
        }else if (turn == ai.getColor()) {
            ai.move(this);
            if (this.turn == Player.WHITE) this.turn = Player.BLACK;
            else this.turn = Player.WHITE;
        } else {
            if (click) {
                text(xClicked + " " + yClicked, 700, 360);
                if (board[xClicked][yClicked].getPiece() != null
                        && board[xClicked][yClicked].getPiece().getColor() == turn) {
                    selectedCell = board[xClicked][yClicked];
                    int i = 0;
                    while (i < BOARD_WIDTH) {
                        int j = 0;
                        while (j < BOARD_WIDTH) {
                            if ((i + j) % 2 == 0) this.board[i][j].setColor(OtherColor.LIGHT_BROWN);
                            else this.board[i][j].setColor(OtherColor.DARK_BROWN);
                            j++;
                        }
                        i++;
                    }
                    board[xClicked][yClicked].setColor(OtherColor.GREEN);
                    board[xClicked][yClicked].getPiece().select(this);
                } else if (board[xClicked][yClicked].getColor() == OtherColor.LIGHT_BLUE || board[xClicked][yClicked].getColor() == OtherColor.DARK_BLUE || board[xClicked][yClicked].getColor() == OtherColor.ORANGE) {
                    selectedCell.getPiece().move(this, xClicked, yClicked);
                    lastMove[0] = null;
                    lastMove[1] = null;
                    int i = 0;
                    while (i < BOARD_WIDTH) {
                        int j = 0;
                        while (j < BOARD_WIDTH) {
                            if ((i + j) % 2 == 0) this.board[i][j].setColor(OtherColor.LIGHT_BROWN);
                            else this.board[i][j].setColor(OtherColor.DARK_BROWN);
                            j++;
                        }
                        i++;
                    }
                    if (this.turn == Player.WHITE) this.turn = Player.BLACK;
                    else this.turn = Player.WHITE;
                    selectedCell = null;
                }
            }
            click = false;
        }

    }

    /**
     * Obtain the corresponding player's king
     * @param board Checkerboard
     * @param color Game player
     * @return If it is the corresponding player's king, return the chess piece; otherwise, return null
     */
    public ChessPiece getKing(Grid[][] board, Player color) {
        int i = 0;
        while (i < BOARD_WIDTH) {
            int j = 0;
            while (j < BOARD_WIDTH) {
                ChessPiece piece = board[i][j].getPiece();
                if ((piece instanceof King) && (piece.getColor() == color))
                    return board[i][j].getPiece();
                j++;
            }
            i++;
        }
        return null;
    }

    /**
     * update timer
     * @param timerWhite Timer on the side of the white chess piece
     * @param timerBlack Timer on the side of the black chess piece
     * @param turn Current player
     */
    public void updateTime(Time timerWhite, Time timerBlack, Player turn) {
        if (timerBlack.getTime() <= 0 || timerWhite.getTime() <= 0 || isCheckMate(turn)) {
            timerBlack.finish();
            timerWhite.finish();
        } else if (turn == Player.WHITE) {
            if (timerBlack.isRunning()) {
                timerBlack.stop();
            }
            if (!timerWhite.isRunning()) {
                timerWhite.start();
            }
        } else {
            if (timerWhite.isRunning()) {
                timerWhite.stop();
            }
            if (!timerBlack.isRunning()) {
                timerBlack.start();
            }
        }
    }

    /**
     * Calculate score
     * @return Score
     */
    public double getScore() {
        double score = 0;
        int i = 0;
        while (i < BOARD_WIDTH) {
            int j = 0;
            while (j < BOARD_WIDTH) {
                ChessPiece piece = board[i][j].getPiece();
                if (piece != null && !(piece instanceof King)) {
                    double value = piece.getValue();
                    if (piece.getColor() == Player.WHITE) {
                        if (i >= 3 && i <= 10 && j >= 3 && j <= 10) {
                            score++;
                        }
                        score += value;
                    } else {
                        if (i >= 3 && i <= 10 && j >= 3 && j <= 10) {
                            score--;
                        }
                        score -= value;
                    }
                }
                j++;
            }
            i++;
        }
        if (isCheck(Player.WHITE)) {
            score -= 5;
        }
        if (isCheck(Player.BLACK)) {
            score += 5;
        }

        if (isCheckMate(Player.WHITE)) {
            score -= 10000;
        }
        if (isCheck(Player.BLACK)) {
            score += 10000;
        }
        return score;
    }

    /**
     * Display timer
     * @param timerWhite Timer on the side of the white chess piece
     * @param timerBlack Timer on the side of the black chess piece
     * @param turn Current player
     */
    public void displayTime(Time timerWhite, Time timerBlack, Player turn) {
        fill(255, 255, 255);
        long time_white = timerWhite.getTime();
        long time_black = timerBlack.getTime();
        String seconds = Long.toString(time_white % 60);
        if (time_white % 60 < 10) seconds = "0" + seconds;
        String time = Long.toString(time_white / 60) + ":" + seconds;
        text(time, 680, 630);
        seconds = Long.toString(time_black % 60);
        if (time_black % 60 < 10) seconds = "0" + seconds;
        time = Long.toString(time_black / 60) + ":" + seconds;
        text(time, 680, 60);
    }

    public ChessPiece getKing(Player color) {
        return getKing(this.board, color);
    }

    /**
     * Check if General
     * @param turn Game player
     * @return
     */
    public boolean isCheck(Player turn) {
        ChessPiece king = getKing(board, turn);
        ArrayList<ChessPiece> oppositePieces;
        if (turn == Player.WHITE) {
            oppositePieces = getPieces(board, Player.BLACK);
        } else {
            oppositePieces = getPieces(board, Player.WHITE);
        }
        int[] kingPosition = king.getPosition();
        int i = 0;
        while(i < oppositePieces.size()){
            ArrayList<int[]> moves = oppositePieces.get(i).getAvailableCaptures(this);
            int j = 0;
            while(j < moves.size()){
                if (moves.get(j)[0] == kingPosition[0] && moves.get(j)[1] == kingPosition[1]) return true;
                j++;
            }
            i++;
        }
        return false;
    }

    /**
     * Obtain all the pieces of the current player on the chessboard
     * @param color Current player
     * @return all the pieces of the current player on the chessboard
     */
    public ArrayList<ChessPiece> getPieces(Player color) {
        return getPieces(this.board, color);
    }

    /**
     * Obtain all the pieces of the current player on the chessboard
     * @param board Checkerboard
     * @param color Current player
     * @return all the pieces of the current player on the chessboard
     */
    public ArrayList<ChessPiece> getPieces(Grid[][] board, Player color) {
        ArrayList<ChessPiece> pieces = new ArrayList<ChessPiece>();
        int i = 0;
        while (i < BOARD_WIDTH) {
            int j = 0;
            while (j < BOARD_WIDTH) {
                if (board[i][j].getPiece() != null && board[i][j].getPiece().getColor() == color) {
                    ChessPiece piece = board[i][j].getPiece();
                    pieces.add(piece);
                }
                j++;
            }
            i++;
        }
        return pieces;
    }

    /**
     * DDetermine whether the location to be placed is legal
     * @param piece The type of current chess piece
     * @param newX The x-coordinate where the current chess piece will be placed
     * @param newY The y-coordinate where the current chess piece will be placed
     * @return true is legal
     */
    public boolean isLegalMove(ChessPiece piece, int newX, int newY) {
        boolean legal = true;
        int[] position = piece.getPosition();
        Grid original_cell = new Grid(board[newX][newY].getColor(), board[newX][newY].getPiece());
        this.board[position[0]][position[1]].setPiece(null);
        this.board[newX][newY].setPiece(piece);
        piece.setPosition(newX, newY);
        if (isCheck(piece.getColor())) {
            legal = false;
        }
        this.board[position[0]][position[1]].setPiece(piece);
        this.board[newX][newY] = original_cell;
        piece.setPosition(position[0], position[1]);
        return legal;
    }

    /**
     * Determine if it is a mate
     * @param turn Current player
     * @return True is yes
     */
    public boolean isCheckMate(Player turn) {
        ArrayList<ChessPiece> pieces = getPieces(turn);
        for (ChessPiece piece : pieces) {
            if (piece.getLegalMoves(this).size() > 0) {
                return false;
            }
        }
        if (isCheck(turn)) {
            return true;
        }
        return false;
    }

    /**
     * Show chessboard
     */
    private void showBoard() {
        if (lastMove[0] != null && lastMove[1] != null) {
            if (board[lastMove[0][0]][lastMove[0][1]].getColor() == OtherColor.LIGHT_BROWN
                    || board[lastMove[0][0]][lastMove[0][1]].getColor() == OtherColor.DARK_BROWN) {
                board[lastMove[0][0]][lastMove[0][1]].setColor(OtherColor.YELLOW);
            }
            if (board[lastMove[1][0]][lastMove[1][1]].getColor() == OtherColor.LIGHT_BROWN
                    || board[lastMove[1][0]][lastMove[1][1]].getColor() == OtherColor.DARK_BROWN) {
                board[lastMove[1][0]][lastMove[1][1]].setColor(OtherColor.YELLOW);
            }
        }
        if (isCheck(turn)) {
            ChessPiece king = getKing(turn);
            int[] position = king.getPosition();
            if (board[position[0]][position[1]].getColor() == OtherColor.LIGHT_BROWN ||
                    board[position[0]][position[1]].getColor() == OtherColor.DARK_BROWN) {
                board[position[0]][position[1]].setColor(OtherColor.RED);
            }
        }
        if (isCheckMate(turn)) {
            ArrayList<ChessPiece> pieces;
            ArrayList<ChessPiece> result = new ArrayList<ChessPiece>();
            ChessPiece king = getKing(turn);
            int[] kingPosition = king.getPosition();
            if (turn == Player.BLACK)
                pieces = getPieces(Player.WHITE);
            else
                pieces = getPieces(Player.BLACK);
            for (int i = 0; i < pieces.size(); i++) {
                ArrayList<int[]> moves = pieces.get(i).getAvailableMoves(this);
                for (int j = 0; j < moves.size(); j++) {
                    if ((Math.abs(moves.get(j)[0] - kingPosition[0]) + Math.abs(moves.get(j)[1] - kingPosition[1]) <= 2)
                            && (Math.abs(moves.get(j)[1] - kingPosition[1]) != 2) && (Math.abs(moves.get(j)[0] - kingPosition[0]) != 2)) {
                        result.add(pieces.get(i));
                    }
                }
            }
            pieces = result;
            for (ChessPiece piece : pieces) {
                int[] position = piece.getPosition();
                board[position[0]][position[1]].setColor(OtherColor.RED);
            }
        }

        for (int i = 0; i < BOARD_WIDTH; i++) {
            for (int j = 0; j < BOARD_WIDTH; j++) {
                fill(this.board[i][j].getColor().R, this.board[i][j].getColor().G, this.board[i][j].getColor().B);
                this.rect(i * CELLSIZE, j * CELLSIZE, CELLSIZE, CELLSIZE);
                if (this.board[i][j].getPiece() != null) {
                    this.board[i][j].getPiece().draw(this);
                }
            }
        }
    }

    /**
     * Set the board color for the movable range of chess pieces
     * @param x The x-coordinate of the mobile piece
     * @param y The y-coordinate of the mobile piece
     */
    public void selectCell(int x, int y) {
        if ((x + y) % 2 == 0) {
            board[x][y].setColor(OtherColor.LIGHT_BLUE);
        } else board[x][y].setColor(OtherColor.DARK_BLUE);
    }

    /**
     * Set the color of this piece to attack another piece
     * @param x The x-coordinate of the attacked chess piece
     * @param y The y-coordinate of the attacked chess piece
     */
    public void selectOccupiedCell(int x, int y) {
        board[x][y].setColor(OtherColor.ORANGE);
    }

    /**
     * Exchange round
     */
    public void ChangeTurn() {
        if (this.turn == Player.WHITE) this.turn = Player.BLACK;
        else this.turn = Player.WHITE;
    }

    /**
     * Determine whether it has been occupied by the enemy
     * @param piece Current chess piece
     * @param x The x-coordinate of the current chess piece
     * @param y The y-coordinate of the current chess piece
     * @return True indicates being occupied by the enemy
     */
    public boolean occupied_by_enemy(ChessPiece piece, int x, int y) {
        if (y < BOARD_WIDTH && y >= 0 && x < BOARD_WIDTH && x >= 0 && board[x][y].getPiece() != null && board[x][y].getPiece().getColor() != piece.getColor())
            return true;
        else return false;
    }

    /**
     * Is the grid of the current chessboard available
     * @param x The x-coordinate of the current grid
     * @param y The y-coordinate of the current grid
     * @return True indicates availability
     */
    public boolean cell_available(int x, int y) {
        if (y < BOARD_WIDTH && y >= 0 && x < BOARD_WIDTH && x >= 0 && board[x][y].getPiece() == null)
            return true;
        return false;
    }


    // Add any additional methods or attributes you want. Please put classes in different files.


    public static void main(String[] args) {
        PApplet.main("XXLChess.App");
    }

}
