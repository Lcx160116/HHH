package XXLChess;
public enum Player {
    WHITE,
    BLACK;
}
