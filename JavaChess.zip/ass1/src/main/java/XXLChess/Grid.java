package XXLChess;
public class Grid {
    private OtherColor color;
    private ChessPiece piece;

    public Grid(OtherColor color, ChessPiece piece){
        this.color = color;
        this.piece = piece;
    }
    
    public Grid(OtherColor color){
        this.color = color;
    }

    public OtherColor getColor(){
        return this.color;
    }

    public void setColor(OtherColor color){
        this.color = color;
    }

    public ChessPiece getPiece(){
        return this.piece; 
    }

    public void setPiece(ChessPiece piece){
        this.piece = piece;
    }
}
