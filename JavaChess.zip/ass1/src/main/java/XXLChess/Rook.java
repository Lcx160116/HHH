package XXLChess;

import processing.core.PImage;

import java.util.ArrayList;

public class Rook extends ChessPiece{

    public Rook(Player color, PImage pieceSprite, int x, int y){
        super(color, pieceSprite, x, y, 5.25);
    }

    /**
     * Moving method of rook
     * @param app
     * @param newX The x-coordinate that needs to be moved
     * @param newY The y-coordinate that needs to be moved
     */
    public void move(App app, int newX, int newY){
        moved = true;
        app.board[this.x][this.y].setPiece(null);
        app.board[newX][newY].setPiece(this);
        this.x = newX;
        this.y = newY;
    }

    /**
     * Obtain a movable sequence of numbers
     * @param app
     * @return Movable sequence
     */
    public ArrayList<int[]> getAvailableMoves(App app){
        ArrayList<int[]> available_moves = new ArrayList<int[]>();
        available_moves.addAll(this.getMovesRow(app));
        available_moves.addAll(this.getMovesColumn(app));
        return available_moves;
    }
}