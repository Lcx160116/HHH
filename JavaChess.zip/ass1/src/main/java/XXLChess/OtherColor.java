package XXLChess;
public enum OtherColor {
    LIGHT_BLUE (197, 224, 231),
    DARK_BLUE (175, 209, 219),
    LIGHT_BROWN (238, 215, 183),
    DARK_BROWN (176, 136, 100),
    GREEN (108,137,79),
    YELLOW (167,160,70),
    ORANGE (250, 165, 110),
    RED (218, 33, 30);
    public final int R;
    public final int G;
    public final int B;
    OtherColor(int R, int G, int B){
        this.R = R;
        this.G = G;
        this.B = B;
    }
}
