package XXLChess;

import processing.core.PImage;

import java.util.ArrayList;

public class Amazon extends ChessPiece{
    public Amazon(Player color, PImage pieceSprite, int x, int y){
        super(color, pieceSprite, x, y, 12);
    }

    /**
     * Obtain a movable sequence of numbers
     * @param app
     * @return Movable sequence
     */
    public ArrayList<int[]> getAvailableMoves(App app){
        ArrayList<int[]> available_moves = new ArrayList<int[]>();
        available_moves.addAll(this.getSpecialMoves(app, Knight.possible_moves));
        available_moves.addAll(this.getMovesRow(app));
        available_moves.addAll(this.getMovesColumn(app));
        available_moves.addAll(this.getMovesDiagonals(app));
        return available_moves;
    }
}

