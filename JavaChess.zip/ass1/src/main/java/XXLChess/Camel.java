package XXLChess;

import processing.core.PImage;

import java.util.ArrayList;

public class Camel extends ChessPiece{
    public static int[][] possible_moves = {{3,1},{-3,1},{-3,-1},{3,-1},{1,3},{-1,3},{-1,-3},{1,-3}};
    public Camel(Player color, PImage pieceSprite, int x, int y){
        super(color, pieceSprite, x, y, 2);
    }

    /**
     * Obtain a movable sequence of numbers
     * @param app
     * @return Movable sequence
     */
    public ArrayList<int[]> getAvailableMoves(App app){
        ArrayList<int[]> available_moves = new ArrayList<int[]>();
        available_moves.addAll(this.getSpecialMoves(app, possible_moves));
        return available_moves;
    }
}