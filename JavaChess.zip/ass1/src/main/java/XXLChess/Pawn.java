package XXLChess;

import processing.core.PImage;

import java.util.ArrayList;

public class Pawn extends ChessPiece{

    public Pawn(Player color, PImage pieceSprite, int x, int y){
        super(color, pieceSprite, x, y, 1);
    }

    /**
     * Moving method of Pawn
     * @param app
     * @param newX The x-coordinate that needs to be moved
     * @param newY The y-coordinate that needs to be moved
     */
    public void move(App app, int newX, int newY){
        app.board[this.x][this.y].setPiece(null);
        if(newY == App.BOARD_WIDTH - 8 && this.color == Player.WHITE){
            app.board[newX][newY].setPiece(new Queen(Player.WHITE, App.wQueen, newX, newY));
        }
        else if(newY == 7 && this.color == Player.BLACK){
            app.board[newX][newY].setPiece(new Queen(Player.BLACK, App.bQueen, newX, newY));
        }
        else{
            this.x = newX;
            this.y = newY;
            app.board[newX][newY].setPiece(this);
        }
    }

    /**
     * Obtain a movable sequence of numbers
     * @param app
     * @return Movable sequence
     */
    public ArrayList<int[]> getAvailableMoves(App app){
        int direction;
        ArrayList<int[]> available_moves = new ArrayList<int[]>();
        if (this.color == Player.BLACK) direction = 1;
        else direction = -1;
        if (app.cell_available(x, y+1*direction)){
            available_moves.add(new int[] {this.x,this.y+1*direction});
            if((this.y == 1 || this.y == 12) && (app.cell_available(this.x,this.y+2*direction))){
                available_moves.add(new int[] {this.x,this.y+2*direction});
            }
        }
        if (app.occupied_by_enemy(this, x+1, y+1*direction)){
            available_moves.add(new int[] {x+1, y+1*direction});
        }
        if (app.occupied_by_enemy(this, x-1, y+1*direction)){
            available_moves.add(new int[] {x-1, y+1*direction});
        }
        return available_moves;
    }
}
