package XXLChess;

import processing.core.PImage;

import java.util.ArrayList;

public class Guard extends ChessPiece{
    public Guard(Player color, PImage pieceSprite, int x, int y){
        super(color, pieceSprite, x, y, 5);
    }

    /**
     * Obtain a movable sequence of numbers
     * @param app
     * @return Movable sequence
     */
    public ArrayList<int[]> getAvailableMoves(App app){
        ArrayList<int[]> available_moves = new ArrayList<int[]>();
        available_moves.addAll(this.getSpecialMoves(app, Knight.possible_moves));
        available_moves.addAll(this.getSpecialMoves(app, King.possible_moves));
        return available_moves;
    }
}