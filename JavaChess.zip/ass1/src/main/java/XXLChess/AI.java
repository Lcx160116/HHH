package XXLChess;

import java.util.*;

public class AI {
    private Player color;
    private ArrayList<ChessPiece> pieces;


    public AI(App app, Player color){
        this.color = color;
        this.pieces = app.getPieces(this.color);
    }

    public Player getColor(){
        return this.color;
    }

    /**
     * The nest mobile method for computing AI: When the enemy
     * is within the attack range, priority is given to attacking
     * the opponent. If the opponent is not within the attack range,
     * priority is given to moving the surrounding chess pieces
     * @param app
     * @param depth
     * @param turn Current player
     * @return Best mobile method
     */
    public int[][] minimax(App app, int depth, Player turn) {
        if (depth == 0 || app.isCheckMate(Player.WHITE) || app.isCheckMate(Player.BLACK)) {
            return null;
        }
        if (turn == Player.WHITE) {
            double bestScore = -100000;
            int[][] bestMove = null;
            ArrayList<ChessPiece> pieces = app.getPieces(turn);
            for (int i = 0; i < pieces.size(); i++){
                ArrayList<int[]> moves = pieces.get(i).getLegalMoves(app);
                for(int j = 0; j < moves.size(); j++){
                    Grid original_cell = new Grid(app.board[moves.get(j)[0]][moves.get(j)[1]].getColor(),
                            app.board[moves.get(j)[0]][moves.get(j)[1]].getPiece());
                    int[] positions = pieces.get(i).getPosition();
                    app.board[positions[0]][positions[1]].setPiece(null);
                    app.board[moves.get(j)[0]][moves.get(j)[1]].setPiece(pieces.get(i));
                    pieces.get(i).setPosition(moves.get(j)[0],moves.get(j)[1]);
                    int[][] oppBestMove = minimax(app, depth - 1, Player.BLACK);
                    if (oppBestMove != null){
                        int[] oppPosition = oppBestMove[0];
                        int[] oppMove = oppBestMove[1];
                        Grid oppOriginalCell = new Grid(app.board[oppMove[0]][oppMove[1]].getColor(), app.board[oppMove[0]][oppMove[1]].getPiece());
                        ChessPiece oppPiece = app.board[oppPosition[0]][oppPosition[1]].getPiece();
                        app.board[oppPosition[0]][oppPosition[1]].setPiece(null);
                        app.board[oppMove[0]][oppMove[1]].setPiece(oppPiece);
                        oppPiece.setPosition(oppMove[0],oppMove[1]);
                        double score = app.getScore();
                        if (score > bestScore){
                            bestScore = score;
                            bestMove = new int[][] {{positions[0],positions[1]}, {moves.get(j)[0],moves.get(j)[1]}};
                        }
                        app.board[oppPosition[0]][oppPosition[1]].setPiece(oppPiece);
                        app.board[oppMove[0]][oppMove[1]] = oppOriginalCell;
                        oppPiece.setPosition(oppPosition[0], oppPosition[1]);
                    }
                    else{
                        double score = app.getScore();
                        if (score > bestScore){
                            bestScore = score;
                            bestMove = new int[][] {{positions[0],positions[1]}, {moves.get(j)[0],moves.get(j)[1]}};
                        }
                    }
                    app.board[positions[0]][positions[1]].setPiece(pieces.get(i));
                    app.board[moves.get(j)[0]][moves.get(j)[1]] = original_cell;
                    pieces.get(i).setPosition(positions[0], positions[1]);
                }
            }
            return bestMove;
        }
        else {
            double bestScore = 100000;
            int[][] bestMove = null;
            ArrayList<ChessPiece> pieces = app.getPieces(turn);
            int i = 0;
            while(i < pieces.size()){
                ArrayList<int[]> moves = pieces.get(i).getLegalMoves(app);
                int j = 0;
                while(j < moves.size()){
                    Grid originalCell = new Grid(app.board[moves.get(j)[0]][moves.get(j)[1]].getColor(),
                            app.board[moves.get(j)[0]][moves.get(j)[1]].getPiece());
                    int[] position = pieces.get(i).getPosition();
                    app.board[position[0]][position[1]].setPiece(null);
                    app.board[moves.get(j)[0]][moves.get(j)[1]].setPiece(pieces.get(i));
                    pieces.get(i).setPosition(moves.get(j)[0],moves.get(j)[1]);
                    int[][] oppBestMove = minimax(app, depth - 1, Player.WHITE);
                    if (oppBestMove != null){
                        int[] oppPosition = oppBestMove[0];
                        int[] oppMove = oppBestMove[1];
                        Grid oppOriginalCell = new Grid(app.board[oppMove[0]][oppMove[1]].getColor(),
                                app.board[oppMove[0]][oppMove[1]].getPiece());
                        ChessPiece oppPiece = app.board[oppPosition[0]][oppPosition[1]].getPiece();

                        app.board[oppPosition[0]][oppPosition[1]].setPiece(null);
                        app.board[oppMove[0]][oppMove[1]].setPiece(oppPiece);
                        oppPiece.setPosition(oppMove[0],oppMove[1]);
                        double score = app.getScore();
                        if (score < bestScore){
                            bestScore = score;
                            bestMove = new int[][] {{position[0],position[1]}, {moves.get(j)[0],moves.get(j)[1]}};
                        }
                        app.board[oppPosition[0]][oppPosition[1]].setPiece(oppPiece);
                        app.board[oppMove[0]][oppMove[1]] = oppOriginalCell;
                        oppPiece.setPosition(oppPosition[0], oppPosition[1]);
                    }
                    else{
                        double score = app.getScore();
                        if (score < bestScore){
                            bestScore = score;
                            bestMove = new int[][] {{position[0],position[1]}, {moves.get(j)[0],moves.get(j)[1]}};
                        }
                    }
                    app.board[position[0]][position[1]].setPiece(pieces.get(i));
                    app.board[moves.get(j)[0]][moves.get(j)[1]] = originalCell;
                    pieces.get(i).setPosition(position[0], position[1]);
                    j++;
                }
                i++;
            }
            return bestMove;
        }
    }

    /**
     * It's AI's turn to play chess, AI moves the pieces
     * @param app
     */
    public void move(App app){
        if (app.isCheck(app.turn)){
            ChessPiece king = app.getKing(app.turn);
            int[] position = king.getPosition();
            app.board[position[0]][position[1]].setColor(OtherColor.RED);
        }
        int[][] minMaxMove = minimax(app, 2, app.turn);
        ChessPiece piece = app.board[minMaxMove[0][0]][minMaxMove[0][1]].getPiece();
        app.lastMove[0] = new int[] {piece.getPosition()[0],piece.getPosition()[1]};
        app.lastMove[1] = new int[] {minMaxMove[1][0], minMaxMove[1][1]};
        piece.move(app, minMaxMove[1][0], minMaxMove[1][1]);
        return;
    }
}