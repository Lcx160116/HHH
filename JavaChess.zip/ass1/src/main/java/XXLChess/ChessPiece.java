package XXLChess;

import java.util.ArrayList;
import processing.core.PImage;

public abstract class ChessPiece {
    protected int x;
    protected int y;
    protected Player color;
    protected double value;
    protected PImage pieceSprite;
    protected boolean moved;

    public ChessPiece(Player color, PImage pieceSprite, int x, int y, double value){
        this.pieceSprite = pieceSprite;
        this.x = x;
        this.y = y;
        this.value = value;
        this.color = color;
    }

    public int[] getPosition(){
        int[] position = {this.x, this.y};
        return position;
    }

    /**
     * Obtain a movable sequence of numbers
     * @param app
     * @return Movable sequence
     */
    public abstract ArrayList<int[]> getAvailableMoves(App app);

    /**
     * Obtain all chess pieces that can capture
     * @param app
     * @return all chess pieces that can capture
     */
    public ArrayList<int[]> getAvailableCaptures(App app){
        ArrayList<int[]> availableCaptures = new ArrayList<int[]>();
        ArrayList<int[]> availableMoves = this.getAvailableMoves(app);
        for (int i = 0; i < availableMoves.size(); i++){
            if (app.occupied_by_enemy(this, availableMoves.get(i)[0], availableMoves.get(i)[1])){
                availableCaptures.add(new int[] {availableMoves.get(i)[0], availableMoves.get(i)[1]});
            }
        }
        return availableCaptures;
    }

    /**
     * Select a valid move location
     * @param app
     */
    public void select(App app){
        ArrayList<int[]> effectiveMoves = this.getLegalMoves(app);
        for (int i = 0; i < effectiveMoves.size(); i++){
            if (app.cell_available(effectiveMoves.get(i)[0], effectiveMoves.get(i)[1])) app.selectCell(effectiveMoves.get(i)[0],
                    effectiveMoves.get(i)[1]);
            else app.selectOccupiedCell(effectiveMoves.get(i)[0], effectiveMoves.get(i)[1]);
        }
    }


    /**
     * Move the chess piece at this coordinate to a new coordinate
     * @param app
     * @param newX New x coordinate
     * @param newY New y coordinate
     */
    public void move(App app, int newX, int newY){
        app.board[this.x][this.y].setPiece(null);
        app.board[newX][newY].setPiece(this);
        this.x = newX;
        this.y = newY;
    }

    public void setPosition(int x, int y){
        this.x = x;
        this.y = y;
    }

    public Player getColor(){
        return this.color;
    }

    public double getValue(){
        return this.value;
    }

    /**
     * Draw chess pieces on the chessboard
     * @param app
     */
    public void draw(App app){
        if (pieceSprite.width != App.CELLSIZE && pieceSprite.height != App.CELLSIZE){
            pieceSprite.resize(App.CELLSIZE, App.CELLSIZE);
        }
        app.image(pieceSprite, x*app.CELLSIZE, y*app.CELLSIZE);
    }

    /**
     * Get Row Move Range
     * @param app
     * @return Row Move Range
     */
    protected ArrayList<int[]> getMovesRow(App app){
        ArrayList<int[]> availableMoves = new ArrayList<int[]>();
        int nowX = this.x+1;
        while(nowX < app.BOARD_WIDTH){
            if (app.cell_available(nowX, this.y)){
                availableMoves.add(new int[] {nowX, this.y});
            }
            else if(app.occupied_by_enemy(this, nowX, this.y)){
                availableMoves.add(new int[] {nowX, this.y});
                break;
            }
            else break;
            nowX ++;
        }
        nowX = this.x-1;
        while(nowX >= 0){
            if (app.cell_available(nowX, this.y)){
                availableMoves.add(new int[] {nowX, this.y});
            }
            else if(app.occupied_by_enemy(this, nowX, this.y)){
                availableMoves.add(new int[] {nowX, this.y});
                break;
            }
            else break;
            nowX--;
        }
        return availableMoves;
    }

    /**
     * Get Column Move Range
     * @param app
     * @return Column Move Range
     */
    protected ArrayList<int[]> getMovesColumn(App app){
        ArrayList<int[]> moves = new ArrayList<int[]>();
        int nowY = this.y+1;
        while(nowY < app.BOARD_WIDTH){
            if (app.cell_available(this.x, nowY)){
                moves.add(new int[] {this.x, nowY});
            }
            else if(app.occupied_by_enemy(this, this.x, nowY)){
                moves.add(new int[] {this.x, nowY});
                break;
            }
            else break;
            nowY++;
        }
        nowY = this.y-1;
        while(nowY >= 0){
            if (app.cell_available(this.x, nowY)){
                moves.add(new int[] {this.x, nowY});
            }
            else if(app.occupied_by_enemy(this, this.x, nowY)){
                moves.add(new int[] {this.x, nowY});
                break;
            }
            else break;
            nowY--;
        }
        return moves;
    }

    /**
     * Obtain diagonal movement range
     * @param app
     * @return diagonal movement range
     */
    protected ArrayList<int[]> getMovesDiagonals(App app){
        ArrayList<int[]> available_moves = new ArrayList<int[]>();
        for(int i = 1; i <= app.BOARD_WIDTH; i++){
            if (app.cell_available(this.x + i, this.y + i)){
                available_moves.add(new int[] {this.x + i, this.y + i});
            }
            else if(app.occupied_by_enemy(this, this.x + i, this.y + i)){
                available_moves.add(new int[] {this.x + i, this.y + i});
                break;
            }
            else
                break;
        }
        for(int i = 1; i <= app.BOARD_WIDTH; i++){
            if (app.cell_available(this.x - i, this.y + i)){
                available_moves.add(new int[]{this.x - i, this.y + i});
            }
            else if(app.occupied_by_enemy(this, this.x - i, this.y + i)){
                available_moves.add(new int[] {this.x - i, this.y + i});
                break;
            }
            else
                break;
        }
        
        for(int i = 1; i <= app.BOARD_WIDTH; i++){
            if (app.cell_available(this.x + i, this.y - i)){
                available_moves.add(new int[] {this.x + i, this.y - i});
            }
            else if(app.occupied_by_enemy(this, this.x + i, this.y - i)){
                available_moves.add(new int[] {this.x + i, this.y - i});
                break;
            }
            else
                break;
        }
        for(int i = 1; i <= app.BOARD_WIDTH; i++){
            if (app.cell_available(this.x - i, this.y - i)){
                available_moves.add(new int[] {this.x - i, this.y - i});
            }
            else if(app.occupied_by_enemy(this, this.x - i, this.y - i)){
                available_moves.add(new int[] {this.x - i, this.y - i});
                break;
            }
            else break;
        }
        return available_moves;
    }

    /**
     * Obtain t except for row, column, and diagonal movement
     * @param app
     * @param possibleMoves An array of movable ranges
     * @return
     */
    protected ArrayList<int[]> getSpecialMoves(App app, int[][] possibleMoves){
        ArrayList<int[]> available_moves = new ArrayList<int[]>();
        for (int i = 0; i < possibleMoves.length; i++){
            int curr_x = this.x + possibleMoves[i][0];
            int curr_y = this.y + possibleMoves[i][1];
            if (app.cell_available(curr_x, curr_y) || app.occupied_by_enemy(this, curr_x, curr_y)){
                available_moves.add(new int[] {curr_x, curr_y});
            }
        }
        return available_moves;
    }

    /**
     * Obtaining illegal movement range
     * @param app
     * @return Obtaining a sequence of illegal movement ranges
     */
    public ArrayList<int[]> getIllegalMoves(App app){
        ArrayList<int[]> illegalMoves = new ArrayList<int[]>();
        ArrayList<int[]> availableMoves = this.getAvailableMoves(app);
        for (int i = 0; i < availableMoves.size(); i++){
            if(!app.isLegalMove(this, availableMoves.get(i)[0], availableMoves.get(i)[1])) illegalMoves.add(availableMoves.get(i));
        }
        return illegalMoves;
    }

    /**
     * Obtaining legal movement range
     * @param app
     * @return Obtaining a sequence of legal movement ranges
     */
    public ArrayList<int[]> getLegalMoves(App app){
        ArrayList<int[]> available_moves = getAvailableMoves(app);
        ArrayList<int[]> illegal_moves = getIllegalMoves(app); //new ArrayList<int[]>();
        ArrayList<int[]> moves = new ArrayList<int[]>();
        for(int[] move : available_moves){
            moves.add(new int[] {move[0], move[1]});
            for(int[] illegal_move : illegal_moves){
                if (move[0] == illegal_move[0] && move[1] == illegal_move[1]){
                    moves.remove(moves.size() - 1);
                    break;
                }
            }
        }
        return moves;
    }
}
