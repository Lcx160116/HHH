package XXLChess;

import processing.core.PImage;

import java.util.ArrayList;

public class Queen extends ChessPiece{
    public Queen(Player colour, PImage pieceSprite, int x, int y){
        super(colour, pieceSprite, x, y, 9.5);
    }

    /**
     * Obtain a movable sequence of numbers
     * @param app
     * @return Movable sequence
     */
    public ArrayList<int[]> getAvailableMoves(App app){
        ArrayList<int[]> available_moves = new ArrayList<int[]>();
        available_moves.addAll(this.getMovesDiagonals(app));
        available_moves.addAll(this.getMovesColumn(app));
        available_moves.addAll(this.getMovesRow(app));
        return available_moves;
    }
}
