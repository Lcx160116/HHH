package XXLChess;


import org.junit.jupiter.api.Test;
import processing.core.PApplet;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SampleTest {

    @Test
    public void simpleTest() {
        assertEquals(720,App.HEIGHT);
        assertEquals(1280,App.WIDTH);
        assertEquals(60, App.FPS);

        App app = new App();
        app.loop();
        for(int i = 0; i < app.BOARD_WIDTH; i++){
            for(int j = 0; j < app.BOARD_WIDTH; j++){
                if ((i+j)%2 == 0) app.board[i][j] = new Grid(OtherColor.LIGHT_BROWN);
                else app.board[i][j] = new Grid(OtherColor.DARK_BROWN);
            }
        }
        app.loadBoard("XXLChess/level2.txt");
        app.turn = Player.WHITE;
        AI ai = new AI(app, Player.BLACK);
        ChessPiece piece = app.board[0][13].getPiece();
        piece.move(app,0,12);
        app.ChangeTurn();
        System.out.println(ai.minimax(app, 2, app.turn)[0][0]);
        System.out.println(ai.minimax(app, 2, app.turn)[0][1]);
        System.out.println(ai.minimax(app, 2, app.turn)[1][0]);
        System.out.println(ai.minimax(app, 2, app.turn)[1][1]);
    }

    @Test
    public void basicTest(){
        App app = new App();
        app.noLoop();
        PApplet.runSketch(new String[]{"APP"},app);
        app.setup();
        app.delay(1000);
        app.draw();
    }

}
